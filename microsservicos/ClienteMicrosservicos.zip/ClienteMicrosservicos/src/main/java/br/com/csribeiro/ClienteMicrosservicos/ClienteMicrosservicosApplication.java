package br.com.csribeiro.ClienteMicrosservicos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteMicrosservicosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteMicrosservicosApplication.class, args);
	}

}
