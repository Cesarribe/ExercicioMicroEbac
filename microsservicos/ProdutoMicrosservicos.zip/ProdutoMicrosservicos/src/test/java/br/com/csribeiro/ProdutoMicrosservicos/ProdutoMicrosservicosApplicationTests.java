package br.com.csribeiro.ProdutoMicrosservicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutoMicrosservicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
