package br.com.csribeiro.ClienteMicrosservicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteMicrosservicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
